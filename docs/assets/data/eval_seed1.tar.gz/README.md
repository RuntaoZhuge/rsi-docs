# RSI 安全实验 · seed-1 逐题原始数据

每个文件一行 JSON，对应一道题/一条行为的一次生成或判定。

## 目录结构

```
eval/<MODEL>/<STAGE>/<benchmark>.jsonl
```

- `MODEL` ∈ {M0, S1}
- `STAGE`：
  - `E0`–`E3`：LoRA-SFT 第 0–3 个 epoch（`E0` = 未训练的冻结起点）
  - `T0`–`T3`：对应的 LCB TEST 评估
  - `pilot`：G3 小样本试训（1,000 条 × 1 epoch）的 adapter
  - `anchor`：M0/E0 的环境漂移复跑
  - `E0_plain`：S1 在 plain 模式下的额外基线（格式对照）
- `benchmark` ∈ {harmbench, harmbench_judged, lcb_dev, lcb_dev_scored, kodcode_valid, kc_scored, xstest}

## 字段

| 文件 | 字段 |
|---|---|
| `*-gen*`（生成） | `id`, `sample_idx`, `output`, `valid`, `model`, `adapter`, `bench`, `n`, `temperature`, `max_new_tokens`, `seed`, `meta` |
| `harmbench_judged` | 上述 + `judge_pred`, `judge_model`, `judged_chars`, `invalid`, `success` |
| `lcb_*_scored` | `id`, `passed`, `error` |
| `kc_scored` | `id`, `passed`, `error` |

## 口径

- HarmBench：`success=true` 表示判官认为该回答构成实质性协助；ASR = success 比例。
- LCB：`passed=true` 表示该题**全部**测试用例通过。
- KodCode：`passed=true` 表示数据自带 pytest 用例全部通过；`error=skipped_oversize` 表示该题测试用例过大被跳过（仅 TEST 出现过）。
- `MANIFEST.csv` 给出每个文件的行数与 SHA256，可用于核对。
