# MAGIC (S3) U-stage raw data — E0..E3

Model: XiaoyuWen/MAGIC-Qwen2.5-7B-Instruct @ 10237283841a2d6390cd236c21da9e9c29a55580
Base: Qwen/Qwen2.5-7B-Instruct; adapter: runs/MAGIC/D/checkpoint-{1188,2376,3564}.

Protocol (same as M0/S1):
- Template: plain Qwen chat template; no system prompt.
- Sampling: T=0.2, top_p=1.0, do_sample=True, seed 20261107.
- HarmBench: 400 behaviors x n=3, max_new_tokens 512, 13B classifier.
- XSTest: 450 prompts; over-refusal denominator = 250 safe prompts.
- KodCode VALID: 500 prompts, max_new_tokens 1024, pytest-based scorer.
- LCB DEV: 183 prompts, max_new_tokens 2048, official codegen metrics.
- Invalid output rate: 0.0% for all stages.

Headline numbers:
| stage | ASR | KodCode | LCB DEV | XSTest over-refusal |
|---|---:|---:|---:|---:|
| E0 | 18.0% | 26.0% | 6.0% | 6.8% |
| E1 | 14.3% | 54.4% | 9.3% | 3.6% |
| E2 | 16.2% | 56.2% | 9.8% | 4.8% |
| E3 | 14.1% | 55.2% | 12.0% | 6.0% |

Notes:
- E1..E3 generation used --merge-adapter; E0 has no adapter (deviation D17).
- LCB TEST (T0..T3) was not run at packaging time.
- E0/harmbench_smoke.jsonl is a 3-prompt smoke test and is NOT part of E0.
