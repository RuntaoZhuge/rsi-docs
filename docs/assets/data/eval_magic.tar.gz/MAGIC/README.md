# MAGIC (S3) U-stage raw data — DEV + LCB TEST

Model: XiaoyuWen/MAGIC-Qwen2.5-7B-Instruct @ 10237283841a2d6390cd236c21da9e9c29a55580
Base: Qwen/Qwen2.5-7B-Instruct; adapter: runs/MAGIC/D/checkpoint-{1188,2376,3564}.

Protocol (same as M0/S1):
- Template: plain Qwen chat template; no system prompt; no --s1-mode.
- Sampling: T=0.2, top_p=1.0, do_sample=True, seed 20261107.
- HarmBench: 400 behaviors x n=3, max_new_tokens 512, 13B classifier.
- XSTest: 450 prompts; over-refusal denominator = 250 safe prompts.
- KodCode VALID: 500 prompts, max_new_tokens 1024, pytest-based scorer.
- LCB DEV / TEST: 183 / 182 prompts, max_new_tokens 2048, official codegen metrics.
- Inference: checkpoint adapter mounted directly (NOT merged), same as M0/S1.
- Invalid output rate: 0.0% for all stages.

Headline numbers (canonical, unmerged):
| stage | ASR | KodCode | LCB DEV | LCB TEST | LCB 365 | XSTest over-refusal |
|---|---:|---:|---:|---:|---:|---:|
| E0/T0 | 18.0% | 26.0% | 6.0% | 9.9% | 7.9% | 6.8% |
| E1/T1 | 14.8% | 54.4% | 11.5% | 15.9% | 13.7% | 4.0% |
| E2/T2 | 15.4% | 55.4% | 10.9% | 17.0% | 14.0% | 4.8% |
| E3/T3 | 13.3% | 55.4% | 13.1% | 17.0% | 15.1% | 6.8% |

Layout:
- MAGIC/E0..E3: canonical DEV outputs (unmerged adapter).
- MAGIC/T0..T3: LCB TEST outputs.
- MAGIC/audit_merged/E1_merged..E3_merged: old merged-adapter runs used for the D17 check.
- MAGIC/D17_COMPARE.md: merged vs unmerged comparison.
- MANIFEST.csv: line counts, bytes and SHA256 for every file.

Notes:
- E0 has no adapter, so it is shared by both inference paths.
- LCB TEST has 2 oversize cases marked skipped_oversize (scored False), same as M0/S1.
- LCB DEV in the merged runs is 1.1-2.2pp lower than unmerged; see D17_COMPARE.md.
