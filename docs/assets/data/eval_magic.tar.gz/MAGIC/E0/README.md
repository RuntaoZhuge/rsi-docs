# MAGIC defender E0 raw data (2026-11-19)

Model: XiaoyuWen/MAGIC-Qwen2.5-7B-Instruct @ 10237283841a2d6390cd236c21da9e9c29a55580
(base Qwen/Qwen2.5-7B-Instruct, Apache-2.0, 15.2GB, 4 shards)
Remote path: /root/private_data/rsi/eval/MAGIC/E0
Pulled with experiments/scnet/sync.sh pull; hashes in SHA256SUMS / MANIFEST.csv.

## Protocol
- Template: plain Qwen chat template, no system prompt, no adapter.
- Sampling: T=0.2, top_p=1.0, do_sample=True, seed 20261107.
- HarmBench: 400 behaviors x n=3, max_new_tokens 512, 13B classifier (models/judge_harmbench).
- XSTest: 450 prompts, max_new_tokens 512; over-refusal denominator = 250 safe prompts.
- KodCode VALID: 500 prompts, max_new_tokens 1024, pytest-based eval_kodcode.py.
- LCB DEV: 183 prompts, max_new_tokens 2048, eval_lcb.py (chunk 10, timeout 10).
- Invalid output rate: 0.0%.

## Headline numbers
| metric | value |
|---|---|
| HarmBench ASR | 18.0% (216/1200) |
| XSTest over-refusal (safe) | 6.8% (17/250) |
| KodCode VALID pass@1 | 26.0% (130/500) |
| LCB DEV pass@1 | 6.0% (11/183) |
| mean / median judged chars | 1086 / 750 |

## Files
- harmbench.jsonl / harmbench_judged.jsonl: raw generations and per-item judge.
- xstest.jsonl / xstest_scored.jsonl: raw and refusal scoring.
- kodcode_valid.jsonl / kc_scored.jsonl: raw and pytest results.
- lcb_dev.jsonl / lcb_dev_scored.jsonl: raw and LCB execution results.
- harmbench_smoke.jsonl: 3-prompt smoke from 2026-11-17, NOT part of E0.
- *.log: generation/judge/score logs.

## Caveat
This is our protocol, not the paper's: the paper uses Qwen3Guard, T=0, an 8192-token cap (then 512 for judge),
and 320 vanilla + 1500 adversarial HarmBench prompts. Absolute ASR is therefore not directly comparable;
relative comparison to M0/S1 under this same protocol is the intended use.
