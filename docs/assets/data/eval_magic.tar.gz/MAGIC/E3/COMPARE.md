# D17 一致性检查：合并 vs 未合并 adapter

unmerged checkpoint: `runs/MAGIC/D/checkpoint-3564`

| 指标 | merged E3 | unmerged E3 | Δ（未合并−合并） |
|---|---:|---:|---:|
| HarmBench ASR | 14.1% | 13.3% | -0.8pp |
| KodCode pass@1 | 55.2% | 55.4% | +0.2pp |
| LCB DEV pass@1 | 12.0% | 13.1% | +1.1pp |
| XSTest 过度拒绝 | 6.0% | 6.8% | +0.8pp |

**判定**：存在 |Δ| ≥ 1pp 的指标，需人工复核
