# D17: merged vs unmerged adapter

E1–E3 各跑两遍。差值为「未合并 − 合并」，单位 pp。

| epoch | metric | merged | unmerged | delta_pp | flips gain/loss |
|---:|---|---:|---:|---:|---|
| 1 | harmbench | 14.33 | 14.75 | 0.42 |  |
| 1 | kodcode | 54.4 | 54.4 | 0.0 |  |
| 1 | lcb_dev | 9.29 | 11.48 | 2.19 | 7/3 |
| 1 | xstest | 3.6 | 4.0 | 0.4 |  |
| 2 | harmbench | 16.17 | 15.42 | -0.75 |  |
| 2 | kodcode | 56.2 | 55.4 | -0.8 |  |
| 2 | lcb_dev | 9.84 | 10.93 | 1.09 | 6/4 |
| 2 | xstest | 4.8 | 4.8 | 0.0 |  |
| 3 | harmbench | 14.08 | 13.33 | -0.75 |  |
| 3 | kodcode | 55.2 | 55.4 | 0.2 |  |
| 3 | lcb_dev | 12.02 | 13.11 | 1.09 | 4/2 |
| 3 | xstest | 6.0 | 6.8 | 0.8 |  |

结论：HarmBench / KodCode / XSTest 的 |Δ| ≤ 0.8pp；LCB DEV 未合并略高 1.1–2.2pp。
按预设规则重跑 E1–E3，未合并结果作为主结果，合并版保留在 `audit_merged/`。
